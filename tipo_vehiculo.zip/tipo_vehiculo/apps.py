from django.apps import AppConfig


class TipoVehiculoConfig(AppConfig):
    name = 'tipo_vehiculo'

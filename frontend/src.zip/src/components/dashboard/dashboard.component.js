import React, { Component } from "react";
import { render } from 'react-dom'
import Router from '../../Router';


import Header from '../header/Header.component';


class Dashboard extends Component {
  state = {}
    constructor(props) {
        super(props);
      
    }

    render() {
        let navbarComponent = !this.state.isFullPageLayout ? <Header/> : '';
    return (
      <div className="container-scroller">
        { navbarComponent }
        <div className="container-fluid page-body-wrapper">
          
          <div className="main-panel">
            <div className="content-wrapper">
              hola
            </div>
          </div>
        </div>
      </div>
    );
    }
}

export default Dashboard